<div id="sidebar" class="span3">
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
			<li class="subMenu"><a> CATEGORIAS</a>
				<ul>
				<li><a class="active" href="{{route('producto.index')}}"><i class="icon-chevron-right"></i>Camaras (100) </a></li>
				<li><a href="{{route('producto.index')}}"><i class="icon-chevron-right"></i>Computadores, Tablets y Portátiles (30)</a></li>
				<li><a href="{{route('producto.index')}}"><i class="icon-chevron-right"></i>Celulares (80)</a></li>
				<li><a href="{{route('producto.index')}}"><i class="icon-chevron-right"></i>Audio y Vídeo (15)</a></li>
				</ul>
			</li>
		</ul>

	</div>
