<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

//tbl_ServidorCorreo
class MailServer extends Model
{
    use HasFactory;
}
