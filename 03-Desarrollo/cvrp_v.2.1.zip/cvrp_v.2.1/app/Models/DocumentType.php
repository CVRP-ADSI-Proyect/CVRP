<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

//tbl_TipoDocumento
class DocumentType extends Model
{
    use HasFactory;
}
