<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>CVRP - Nuevo Milenio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('themes/images/ico/logo_cvrp.ico')); ?>">
</head>
<body>
<!-- Header====================================================================== -->
<?php echo $__env->make('header/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End====================================================================== -->
<div class="container">
    <div class="row">
        <table class="table table-bordered mx-4 my-4 table-hover">
            <thead>
            <tr>
                <th>Id</th>
                <th>Nombre Producto</th>
                <th>Cantidad</th>
                <th>Estado</th>
                <th>Descripción</th>
                <th>Valor</th>
                <th>Imagen</th>
                <th>Disponible</th>
                <th>Categoría</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo e($producto->id); ?></td>
                <td><?php echo e($producto->NombreProducto); ?></td>
                <td><?php echo e($producto->cantidad); ?></td>
                <td><?php echo e($producto->estado); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e("$ ".number_format($producto->valor,0)); ?></td>
                <td><img width="100" src="<?php echo e(Storage::url($producto->imagen)); ?>" alt="<?php echo e($producto->NombreProducto); ?>"></td>
                <td><?php echo e($producto->disponible); ?></td>
                <td><?php echo e($producto->categoria->NombreCategoria); ?></td>
            </tr>
            </tbody>
        </table>
        <a class="btn btn-info mt-4 mx-4" href="<?php echo e(route('producto.index')); ?>">Volver</a>
    </div>
</div>
<!-- Footer ================================================================== -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END FOOTER ==========================================================================================-->
</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\resources\views/productos/show.blade.php ENDPATH**/ ?>