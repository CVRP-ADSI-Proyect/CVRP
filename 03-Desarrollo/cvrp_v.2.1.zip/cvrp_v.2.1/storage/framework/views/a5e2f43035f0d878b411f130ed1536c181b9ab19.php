<!--Estilos Propios-->
<link rel="stylesheet" href="<?php echo e(URL::asset('css/base.css')); ?>">
<!-- Bootstrap style -->
<link id="callCss" rel="stylesheet" href="<?php echo e(URL::asset('themes/bootshop/bootstrap.min.css')); ?>" media="screen"/>
<link href="<?php echo e(URL::asset('themes/css/base.css')); ?>" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->
<link href="<?php echo e(URL::asset('themes/css/bootstrap-responsive.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(URL::asset('themes/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->
<link href="<?php echo e(URL::asset('themes/js/google-code-prettify/prettify.css')); ?>" rel="stylesheet"/>
<!-- fav and touch icons -->
<link rel="shortcut icon" href="<?php echo e(URL::asset('themes/images/ico/logo_cvrp.ico')); ?>">




<style type="text/css" id="enject"></style>

<div id="header">
    <div class="container">
        <div id="logoArea" class="navbar">
            <a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="navbar-inner">
                <a class="brand" href="<?php echo e(route ('main')); ?>"><img src="<?php echo e(URL::asset('themes/images/logo_cvrp2.webp')); ?>"
                                                                alt="CVRP- NUEVO MILENIO"/></a>
                <form class="form-inline navbar-search" method="get" action="<?php echo e(route ('producto.index')); ?>">
                    <input id="srchFld_" class="srchTxt" type="text" placeholder="Buscar..."/>
                    <select class="srchTxt">
                        <option selected>Todo</option>
                        <option>Cámaras</option>
                        <option>Deporte</option>
                        <option>Electrodomesticos</option>
                        <option>Herramientas</option>
                        <option>Joyeria</option>
                        <option>Videojuegos</option>
                    </select>
                    <button type="submit" id="submitButton" class="btn btn-primary">Ir</button>
                </form>
                <ul id="topMenu" class="nav pull-right">
                    <li class=""><a href="<?php echo e(url('/ofertas')); ?>">Ofertas especiales</a></li>
                    
                    <li class=""><a href="<?php echo e(url('/contacto')); ?>">Contactanos</a></li>
                    <li class="">
                        <a type="submit" href="<?php echo e(route ('login')); ?>" role="button"><span
                                class="btn btn-large btn-success">Ingresar</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Placed at the end of the document so the pages load faster ============================================= -->
<script src="<?php echo e(URL::asset('themes/js/jquery.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('themes/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('themes/js/google-code-prettify/prettify.js')); ?>"></script>
<script src="<?php echo e(URL::asset('themes/js/bootshop.js')); ?>"></script>
<script src="<?php echo e(URL::asset('themes/js/jquery.lightbox-0.5.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/cvrp.js')); ?>"></script>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\resources\views/header/header.blade.php ENDPATH**/ ?>