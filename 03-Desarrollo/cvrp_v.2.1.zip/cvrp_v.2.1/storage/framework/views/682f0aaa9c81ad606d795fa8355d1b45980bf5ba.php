<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>CVRP - Nuevo Milenio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="themes/images/ico/logo_cvrp.ico">
</head>
<body>
<!-- Header====================================================================== -->
<?php echo $__env->make('header/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End====================================================================== -->
<div class="container">
    <div class="row">
        <div class="my-3">
            <form action="<?php echo e(route('producto.index')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <input class="span4" type="text" name="name_product" id=""
                       placeholder="Escriba nombre de Producto: Chaqueta">
                <button type="submit" class="btn btn-success">Filtrar</button>
            </form>
        </div>
        <div class="my-3">
            <a class="btn btn-info" href="<?php echo e(route('producto.create')); ?>">Crear Producto</a>
        </div>
        <table class="table table-bordered my-4 table-hover">
            <thead>
            <tr>
                <th>Id</th>
                <th>Nombre Producto</th>
                <th>Cantidad</th>
                <th>Estado</th>
                <th>Descripción</th>
                <th>Valor</th>
                <th>Imagen</th>
                <th>Disponible</th>
                <th>Categoría</th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($producto->id); ?></th>
                    <th><?php echo e($producto->NombreProducto); ?></th>
                    <th><?php echo e($producto->cantidad); ?></th>
                    <th><?php echo e($producto->estado); ?></th>
                    <th><?php echo e($producto->descripcion); ?></th>
                    <th><?php echo e("$ ".number_format($producto->valor,0)); ?></th>
                    <th><img width="100" src="<?php echo e(Storage::url($producto->imagen)); ?>"
                             alt="<?php echo e($producto->NombreProducto); ?>"></th>
                    <th><?php echo e($producto->disponible); ?></th>
                    <th><?php echo e($producto->categoria->NombreCategoria); ?></th>

                    <th>
                        <a class="btn btn-warning my-1" href="<?php echo e(route('producto.edit',$producto->id)); ?>">Editar</a>
                        <br>
                        <a class="btn btn-info my-1" href="<?php echo e(route('producto.show',$producto->id)); ?>">Mostrar</a>
                        <br>
                        <form action="<?php echo e(route('producto.destroy',$producto->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger my-1" type="submit">Eliminar</button>
                        </form>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Footer ================================================================== -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END FOOTER ==========================================================================================-->
</body>
</html>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\resources\views/productos/index.blade.php ENDPATH**/ ?>