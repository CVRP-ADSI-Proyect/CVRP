<?php echo e($slot); ?>

<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>