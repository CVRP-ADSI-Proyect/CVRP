<div  id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h5>CUENTA</h5>
				<a href="<?php echo e(route('login')); ?>">MI CUENTA</a>
				<a href="<?php echo e(route('login')); ?>">INFORMACION PERSONAL</a>
				<a href="<?php echo e(route('login')); ?>">DESCUENTOS</a>
				<a href="<?php echo e(route('login')); ?>">HISTORIAL DE COMPRAS</a>
			 </div>
			<div class="span3">
				<h5>INFORMACION</h5>
				<a href="<?php echo e(route('contact')); ?>">CONTACTO</a>
				<a href="<?php echo e(route('register')); ?>">REGISTRO</a>
				<a href="<?php echo e(route('legal_notice')); ?>">AVISO LEGAL</a>
				<a href="<?php echo e(route('tac')); ?>">TERMINOS Y CONDICIONES</a>
				<a href="<?php echo e(route('faq')); ?>">FAQ</a>
			 </div>
			<div class="span3">
				<h5>NUESTRAS OFERTAS</h5>
				<a href="<?php echo e(route ('offer')); ?>">NUEVOS PRODUCTOS</a>
				<a href="<?php echo e(route ('offer')); ?>">LOS MÁS VENDIDOS</a>
				<a href="<?php echo e(route ('offer')); ?>">OFERTAS ESPECIALES</a>
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>REDES SOCIALES</h5>
				<a href="https://es-la.facebook.com/" target="_blank"><img width="60" height="60" src="<?php echo e(URL::asset('themes/images/facebook.png')); ?>" title="facebook" alt="facebook"/></a>
				<a href="https://twitter.com/?lang=es" target="_blank"><img width="60" height="60" src="<?php echo e(URL::asset('themes/images/twitter.png')); ?>" title="twitter" alt="twitter"/></a>
				<a href="https://www.youtube.com/?hl=ES" target="_blank"><img width="60" height="60" src="<?php echo e(URL::asset('themes/images/youtube.png')); ?>" title="youtube" alt="youtube"/></a>
			 </div>
		 </div>
		<p class="pull-right">&copy; CVRP</p>
	</div><!-- Container End -->
	</div>
<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\resources\views/footer/footer.blade.php ENDPATH**/ ?>