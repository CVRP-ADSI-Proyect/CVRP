<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Usuario\Documents\GitHub\CVRP\03-Desarrollo\cvrp_v.2.1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>